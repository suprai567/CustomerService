package com.user.entity;

/**
 * 
 * @author supriya ERole enum is used for declaring the role
 *
 */
public enum ERole {
	ROLE_USER, ROLE_ADMIN
}
