package com.User;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginRegisterApplicationTests {

	@Test
	void contextLoads() {
	}

}
